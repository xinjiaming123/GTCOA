
function O=chaos1(Initial_Value,N)
% O=zeros(1,N);
x(1)=Initial_Value;

       % Logistic-Tent
        r=0.3;
        for i=1:N
            if x(i)<0.5
                x(i+1)=mod(r*x(i)*(1-x(i))+(4-r)*x(i)/2,1);
            else
                x(i+1)=mod(r*x(i)*(1-x(i))+(4-r)*(1-x(i))/2,1);
            end
        end
        
        O=x(1:N);
end