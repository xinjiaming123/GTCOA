clc
clear
close all

Fun_name='F1';     %F1-F12
dimension=2;       %2,10,20

SearchAgents=30;                      
Max_iterations=1000;                 
[lowerbound,upperbound,dimension,fitness]=fun_info(Fun_name,dimension); 
[Best_score,Best_pos,GTCOA_curve]=GTCOA(SearchAgents,Max_iterations,lowerbound,upperbound,dimension,fitness);  

display(['The best solution obtained by GTCOA for ' [num2str(Fun_name)],'  is : ', num2str(Best_pos)]);
display(['The best optimal value of the objective funciton found by GTCOA  for ' [num2str(Fun_name)],'  is : ', num2str(Best_score)]);


        