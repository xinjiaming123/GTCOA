%% Chaos initialization
function Positions = Chaos_Initialization(N,dim,lb,ub)

lb=lb.*ones(1,dim);                                                                                 
ub=ub.*ones(1,dim);                                     

for  i=1:dim                                          
    ub_i=ub(i);
    lb_i=lb(i);
    
    chaos_value= chaos(rand(1),N);                                                                                                                         
    Positions(:,i)=abs(chaos_value).*(ub_i-lb_i)+lb_i;     

    end
end

