
function O=chaos(Initial_Value,N)
% O=zeros(1,N);
x(1)=Initial_Value;

      % Kent
        r=0.4;
        for i=1:N
            if x(i)>=0 && x(i)<=r
                x(i+1)=x(i)/r;
            else
                x(i+1)=(1-x(i))/(1-r);   
            end
        end
        
  O=x(1:N);
end