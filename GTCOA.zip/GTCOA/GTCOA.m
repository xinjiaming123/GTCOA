function[Best_score,Best_pos,GTCOA_curve]=GTCOA(SearchAgents_no,Max_iter,lb,ub,dim,fitness)

a=-pi;                           
b=pi;                            
gold=double((sqrt(5)-1)/2);   
x1=a+(1-gold)*(b-a);                      
x2=a+gold*(b-a);                 

NEW_pos = zeros(SearchAgents_no,dim);  
fit_new = zeros(1,SearchAgents_no); 
X_new = zeros(SearchAgents_no, dim); 

X=Chaos_Initialization(SearchAgents_no,dim,lb,ub);

fit = zeros(1,SearchAgents_no);

for i = 1:SearchAgents_no
    L=X(i,:);
    fit(i)=fitness(L);
end

GTCOA_curve=zeros(1,Max_iter); 
chaos_vectors= chaos1(rand(1),Max_iter);

for t=1:Max_iter
    
    [best , location]=min(fit);   
                                         
    if t==1
        Xbest=X(location,:);                                        
        fbest=best;                                         
    elseif best<fbest
        fbest=best;                     
        Xbest=X(location,:);            
    end
    
        for i=1:SearchAgents_no/2        
            iguana=Xbest;
            if rand > 1-sqrt(t/Max_iter)                 
            I=round(1+rand(1,1));     
            X_P1(i,:)=X(i,:)+rand(1,1) .* (iguana-I.*X(i,:));  

            else
             freen = exp(4.*(t/Max_iter).^2); 
             X_P1(i,:)=  iguana+ trnd(freen)*iguana;
            end

             X_P1(i,:) = max(X_P1(i,:),lb);       
             X_P1(i,:) = min(X_P1(i,:),ub);
           
            L=X_P1(i,:);
            F_P1(i)=fitness(L);
            if(F_P1(i)<fit(i))
                X(i,:) = X_P1(i,:);
                fit(i) = F_P1(i);
            end
        end
        for i=1+SearchAgents_no/2 :SearchAgents_no
            iguana=lb+rand.*(ub-lb); 
            L=iguana;
            F_HL=fitness(L);
            I=round(1+rand(1,1));
            
            if fit(i)> F_HL
                X_P1(i,:)=X(i,:)+rand(1,1) .* (iguana-I.*X(i,:)); % Eq. (6)
            else
                X_P1(i,:)=X(i,:)+rand(1,1) .* (X(i,:)-iguana); % Eq. (6)
            end
            X_P1(i,:) = max(X_P1(i,:),lb);
            X_P1(i,:) = min(X_P1(i,:),ub);

            L=X_P1(i,:);
            F_P1(i)=fitness(L);
            if(F_P1(i)<fit(i))
                X(i,:) = X_P1(i,:);
                fit(i) = F_P1(i);
            end
        end

    for i=1:SearchAgents_no                                  
         LO_LOCAL=(lb/t)*chaos_vectors(t);
         HI_LOCAL=(ub/t)*chaos_vectors(t);

         X_P2(i,:)=X(i,:)+(1-2*rand).* (LO_LOCAL+rand(1,1) .* (HI_LOCAL-LO_LOCAL));
         X_P2(i,:) = max(X_P2(i,:),LO_LOCAL);
         X_P2(i,:) = min(X_P2(i,:),HI_LOCAL);
         r=rand;
         r1=(2*pi)*r;
         r2=r*pi;          

        for vv = 1:dim 
            NEW_pos(i,vv) = X(i,vv)*abs(sin(r1)) - r2*sin(r1)*abs(x1*Xbest(1,vv)-x2*X(1,vv));
        end  
        Flag4ub=NEW_pos(i,:)>ub;
        Flag4lb=NEW_pos(i,:)<lb;
        NEW_pos(i,:)=(NEW_pos(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb; 
            L1=X_P2(i,:);
            F_P2_1(i)=fitness(L1);
            L2=NEW_pos(i,:);
            F_P2_2(i)=fitness(L2); 
        if(F_P2_2(i)<F_P2_1(i))
           X_new(i,:)= NEW_pos(i,:);
           fit_new(i)= F_P2_2(i);
        else
            X_new(i,:) = X_P2(i,:);
           fit_new(i) = F_P2_1(i);
        end
        if(fit_new(i)<fit(i))
               X(i,:) = X_new(i,:);
               fit(i) = fit_new(i);
        end

    end 
    best_so_far(t)=fbest;
    average(t) = mean (fit);
end 
Best_score=fbest;
Best_pos=Xbest;
GTCOA_curve=best_so_far;
end